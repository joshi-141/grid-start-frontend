

const CreateNewOrganization = () => {

    return (
        <>
            <h1>Create New Organization Page....</h1>
        </>
    )

}


export default CreateNewOrganization;