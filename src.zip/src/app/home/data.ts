export const userServices = [
  {
    id: 101,
    title: "Modern UI/UX Design for Mobile Apps",
    category: "Design & Creative",
    price: "$120",
    seller: "Rahul",
    image: "/placeholder-service.png",
    rating: 5,
    reviews: 12,
    vetted: false,
  },
  {
    id: 102,
    title: "Need MERN developer for dashboard",
    category: "Development",
    price: "$300 - 600",
    seller: "Client",
    image: "/placeholder-service.png",
    rating: 4.8,
    reviews: 8,
    vetted: false,
  },
];
