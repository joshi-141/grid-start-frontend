

const Lable = ({children}:any) => {
    return (
        <>
        
        </>
    )
}

export default Lable;